"""服装分类服务。"""

from __future__ import annotations

from typing import Any

from fastapi import Request
try:
    from sqlalchemy import text
    from sqlalchemy.exc import SQLAlchemyError
except Exception:  # pragma: no cover - 仅用于依赖未安装时的骨架导入
    def text(sql: str) -> str:
        return sql

    class SQLAlchemyError(Exception):
        """最小化占位数据库异常。"""


from app.core.database import session_scope
from app.core.defaults import DEFAULT_LEVEL_1_CATEGORIES, DEFAULT_LEVEL_2_CATEGORIES
from app.core.deps import CurrentUser
from app.services.base import SkeletonService


class CategoryService(SkeletonService):
    """服装分类服务。"""

    async def init_default_categories(self, user_id: int, operator: str, db: Any | None = None) -> None:
        """为新用户初始化默认服装分类树。"""
        try:
            if db is not None:
                self._init_default_categories_with_session(db=db, user_id=user_id, operator=operator)
                return

            with session_scope() as session:
                self._init_default_categories_with_session(db=session, user_id=user_id, operator=operator)
        except SQLAlchemyError:
            raise

    def _init_default_categories_with_session(self, db: Any, user_id: int, operator: str) -> None:
        """在给定会话里写入默认分类树。"""
        exists = db.execute(
            text('SELECT 1 FROM clothing_category WHERE user_id = :user_id LIMIT 1'),
            {'user_id': user_id},
        ).first()
        if exists is not None:
            return

        order_seed = 1
        parent_mapping: dict[str, int] = {}
        for level1_name in DEFAULT_LEVEL_1_CATEGORIES:
            db.execute(
                text(
                    '''
                    INSERT INTO clothing_category (
                        user_id, parent_id, name, order_value, default_flag,
                        editable_flag, create_by, create_time, update_by, update_time, del_flag
                    ) VALUES (
                        :user_id, 0, :name, :order_value, 1,
                        0, :operator, NOW(), :operator, NOW(), 0
                    )
                    '''
                ),
                {
                    'user_id': user_id,
                    'name': level1_name,
                    'order_value': order_seed,
                    'operator': operator,
                },
            )
            parent_row = db.execute(text('SELECT LAST_INSERT_ID() AS id')).mappings().first()
            if parent_row is not None:
                parent_mapping[level1_name] = int(parent_row['id'])
            order_seed += 1

        for parent_name, children in DEFAULT_LEVEL_2_CATEGORIES.items():
            parent_id = parent_mapping.get(parent_name)
            if parent_id is None:
                continue
            child_order = 1
            for child_name in children:
                db.execute(
                    text(
                        '''
                        INSERT INTO clothing_category (
                            user_id, parent_id, name, order_value, default_flag,
                            editable_flag, create_by, create_time, update_by, update_time, del_flag
                        ) VALUES (
                            :user_id, :parent_id, :name, :order_value, 1,
                            0, :operator, NOW(), :operator, NOW(), 0
                        )
                        '''
                    ),
                    {
                        'user_id': user_id,
                        'parent_id': parent_id,
                        'name': child_name,
                        'order_value': child_order,
                        'operator': operator,
                    },
                )
                child_order += 1

    async def add(
        self,
        request: Request | None = None,
        current_user: CurrentUser | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """add 接口对应的业务方法。"""
        return await self.todo('category_service.add', request=request, current_user=current_user, **kwargs)

    async def update(
        self,
        request: Request | None = None,
        current_user: CurrentUser | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """update 接口对应的业务方法。"""
        return await self.todo('category_service.update', request=request, current_user=current_user, **kwargs)

    async def delete(
        self,
        request: Request | None = None,
        current_user: CurrentUser | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """delete 接口对应的业务方法。"""
        return await self.todo('category_service.delete', request=request, current_user=current_user, **kwargs)

    async def list(
        self,
        request: Request | None = None,
        current_user: CurrentUser | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """list 接口对应的业务方法。"""
        return await self.todo('category_service.list', request=request, current_user=current_user, **kwargs)
