"""数据库连接模块。

这里统一管理 SQLAlchemy engine、Session 工厂，以及少量便捷工具。
为了让骨架在“未连接真实数据库”时也能被导入，仍然保留了最小兜底；
但真实开发时请始终安装依赖并连接实际 MySQL。
"""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from typing import Any

from app.core.config import get_settings

try:
    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session, sessionmaker
except Exception:  # pragma: no cover - 仅用于依赖未安装时的骨架导入
    create_engine = None  # type: ignore[assignment]
    Session = Any  # type: ignore[misc,assignment]
    sessionmaker = None  # type: ignore[assignment]


settings = get_settings()

if create_engine is not None and sessionmaker is not None:
    engine = create_engine(
        settings.database_url,
        pool_pre_ping=True,
        future=True,
    )

    SessionLocal = sessionmaker(
        bind=engine,
        autoflush=False,
        autocommit=False,
        expire_on_commit=False,
        class_=Session,
    )
else:  # pragma: no cover - 仅用于依赖未安装时的骨架导入
    engine = None
    SessionLocal = None


@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """提供一个 with 风格的数据库会话。

    说明：
    1. 业务成功时自动提交。
    2. 出错时自动回滚。
    3. 最终自动关闭会话。
    """
    if SessionLocal is None:
        raise RuntimeError("当前环境未安装 SQLAlchemy，请先安装依赖后再连接数据库。")
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def get_db() -> Generator[Session, None, None]:
    """提供 FastAPI 依赖形式的数据库会话。"""
    if SessionLocal is None:
        raise RuntimeError("当前环境未安装 SQLAlchemy，请先安装依赖后再连接数据库。")
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
